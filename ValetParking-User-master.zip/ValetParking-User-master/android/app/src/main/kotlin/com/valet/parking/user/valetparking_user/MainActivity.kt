package com.valet.parking.user.valetparking_user

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
