// import 'package:flutter/material.dart';
// import 'package:osta_user_app/utils/constants/colors.dart';
//
// class OAppTheme {
//   OAppTheme._();
//
//   static ThemeData lightTheme = ThemeData(
//     useMaterial3: true,
//     fontFamily: 'Urbanist',
//     brightness: Brightness.light,
//     primaryColor: OColors.primaryColor500,
//     bottomNavigationBarTheme: BottomNavigationBarThemeData(
//       backgroundColor: OColors.whiteColor,
//     ),
//     colorScheme: ColorScheme.light(
//       surface: OColors.greyScale50,
//       primary: OColors.greyScale900,
//       onPrimaryContainer: OColors.whiteColor,
//       // secondary: OColors.greyScale900,
//     ),
//   );
//   static ThemeData darkTheme = ThemeData(
//     useMaterial3: true,
//     fontFamily: 'Urbanist',
//     brightness: Brightness.dark,
//     primaryColor: OColors.primaryColor500,
//     bottomNavigationBarTheme: BottomNavigationBarThemeData(
//       backgroundColor: OColors.dark1,
//     ),
//     colorScheme: ColorScheme.dark(
//       surface: OColors.dark1,
//       primary: OColors.whiteColor,
//       onPrimaryContainer: OColors.dark3,
//       // secondary: OColors.whiteColor,
//     ),
//   );
// }
